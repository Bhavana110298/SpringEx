package com.cg;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("exchangeService")
public class ExchangeServiceImpl implements ExchangeService {
	
	@Value("45.0")
	private double exchangeRate;
	

	/*public ExchangeServiceImpl(double exchangeRate) {
		super();
		this.exchangeRate = exchangeRate;
		System.out.println("ExchangeServiceImpl() Cons Invoked");
	}*/
	
	public ExchangeServiceImpl() {
		super();
		System.out.println("ExchangeServiceImpl Invoked");
	}

	@Override
	public double getExchangeRate() {
		System.out.println("getExchangeRate() Invoked");
		return exchangeRate;
	}

}

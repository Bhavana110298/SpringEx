package com.cg;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("currencyConvertor")
public class CurrencyConvertorImpl implements CurrencyConvertor {
	
	@Autowired
	private ExchangeServiceImpl exchangeService;

	//private double exchangeRate;
	//private ExchangeService exchangeService;
	
	public CurrencyConvertorImpl() {
		super();
		System.out.println("CurrencyConvertImpl()");
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
	public CurrencyConvertorImpl(ExchangeServiceImpl exchangeService) {
		super();
		this.exchangeService = exchangeService;
	}
	
	@PostConstruct
	public void init() {
		System.out.println("in init() - invoked by @PostConstruct");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("in destroy() - invoked by @PreDestroy");
	}
	
	
	public ExchangeService getExchangeService() {
		return exchangeService;
	}


	public void setExchangeService(ExchangeServiceImpl exchangeService) {
		this.exchangeService = exchangeService;
	}


	/*public double getExchangeRate() {
		return exchangeRate;
	}


	public void setExchangeRate(double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}


	public CurrencyConvertorImpl(double exchangeRate) {
		super();
		this.exchangeRate = exchangeRate;
	}
*/
	@Override
	public double dollarToRupees(double dollars) {
		System.out.println("dollarToRupees() Invoked");
		//return dollars*exchangeRate;
		return dollars*exchangeService.getExchangeRate();
		
	}
	

}

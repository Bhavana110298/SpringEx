package com.cg;

public interface CurrencyConvertor {
	public double dollarToRupees(double dollars);
}

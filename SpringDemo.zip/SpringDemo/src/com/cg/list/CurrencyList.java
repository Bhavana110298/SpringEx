package com.cg.list;

import java.util.ArrayList;

public interface CurrencyList {
	public ArrayList<String> getCurrList();

}

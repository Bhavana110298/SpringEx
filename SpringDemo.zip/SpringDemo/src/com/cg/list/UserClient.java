package com.cg.list;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ClassPathXmlApplicationContext;


@ComponentScan("com.cg.list")
@EnableAutoConfiguration
@PropertySource("classpath:/user.properties")
public class UserClient {

	public static void main(String[] args) {
			
		//2 containers (BeanFactory,ApplicationContext)
		//AC is sub interface BF
		//BF is container for basic functionalities, AC for advanced functionalities(localization,internationalization,logging,security)
		
		//ApplicationContext ctx=new ClassPathXmlApplicationContext("collection.xml");
		
		ApplicationContext ctx=SpringApplication.run(UserClient.class, args);
		User user=(User) ctx.getBean("user");
		System.out.println(user.getUserName());
		System.out.println(user.getPassword());
		
	}

}

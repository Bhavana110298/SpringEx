package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		/*Resource resource=new ClassPathResource("currencyConvertor.xml");
		BeanFactory factory=new XmlBeanFactory(resource);*/
		ApplicationContext factory=new ClassPathXmlApplicationContext("annotation.xml");
		CurrencyConvertor currency=(CurrencyConvertor) factory.getBean("currencyConvertor");
		double result=currency.dollarToRupees(50.0);
		System.out.println("50 dollar is:"+result);

	}

}

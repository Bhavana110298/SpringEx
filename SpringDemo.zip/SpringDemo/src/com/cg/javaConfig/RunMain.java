package com.cg.javaConfig;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.cg.javaConfig")
public class RunMain {
	
	public static void main(String args[]) {
		ApplicationContext ctx=new AnnotationConfigApplicationContext(ConfigBeans.class);
		Book book=(Book) ctx.getBean("book");
		System.out.println(book);
	}

}

package com.cg.javaConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigBeans {

	@Bean
	public Author author() {
		return new Author("Bhavana","LA");
	}
	
	@Bean
	public Book book() {
		Book book=new Book();
		book.setIsbn("A1234SA");
		book.setYear("2018");
		book.setAuthor(author());
		return book;
	}
}
